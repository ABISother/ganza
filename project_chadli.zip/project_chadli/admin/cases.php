<?php
session_start();
?>
<?php
if(!isset($_SESSION["trans_admin"])){
echo("<script>location.href='login.html?alert=Session ended';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["trans_admin"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }
if(isset($_POST['Submit-btn'])){
  $progress=$_POST['progress'];
  $status=$_POST['status'];
  $key=$_POST['casekey'];
  $now=time();
  
  if(!isset($alert)){
    $update_case=$con->query("UPDATE cases SET status='$status',progress='$progress' WHERE id='$key' ")or die($con->error);
    // $update_marks=$con->query("UPDATE marks SET assignments='$assignment',cat_1='$cat1',cat_2='$cat2',exam='$exam' WHERE id='$marksto' ")or die($con->error);

 // $savequery=$con->query("INSERT INTO messages(msg_time,message_hod,message_user,case_of,readed,tobereceived,the_message) VALUES('$now','$account_key','$student','$case','0','Student','$message')")or die($con->error);
  if ($update_case) {
      $info="Success<br/>This Case Has Just Upgrades!<br> ";
     
         } 
}else{
  $alert='<label style="color:red;">'.$alert.' </label>';
 }

}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Cases / Transparency International Rwanda</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

    <!-- Ajax reasons-->
    <script src="../assets/js/jquery.min.js"></script>



</head>

<body>

  <?php 
  include('header.php');
   ?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Reported Cases</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
         
          <li class="breadcrumb-item active">cases</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">
        <div class="card">

       <?php if(isset($info)){ ?>
        <div class="alert alert-primary bg-primary text-light border-0 alert-dismissible fade show" role="alert">
       <?php echo $info; ?>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      <?php }   ?>
      <?php if(isset($alert)){ ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
       <?php echo $info; ?>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      <?php }   ?>
          <!-- Only if case is opened============================================================= -->
          <?php if(isset($_GET['Q'])){
            $nowcase=$_GET['Q'];
            $sel_cases=$con->query("SELECT*from cases where caseid='$nowcase' ")or die($con->error);
            if($count_cases=$sel_cases->num_rows>0){
            $fetch_cases=$sel_cases->fetch_assoc(); 
              $cate=$fetch_cases['category'];
              $loca=$fetch_cases['location'];
              
            $sel_locations=$con->query("SELECT*from locations where id='$loca' ")or die($con->error);
            $fetch_locations=$sel_locations->fetch_assoc(); 
                       
             $district=$fetch_locations['district'];


             $sel_cate=$con->query("SELECT*from categories where id='$cate' ")or die($con->error);
             $fetch_cate=$sel_cate->fetch_assoc(); 
                        
              $cate=$fetch_cate['c_title'];

                      if($fetch_cate['severity']=='3'){
                          $color='success';
                          $severity='Minor';
                      }elseif($fetch_cate['severity']=='2'){
                          $color='warning';
                          $severity='Major';
                      }elseif($fetch_cate['severity']=='1'){
                          $color='danger';
                          $severity='Critical';
                      }else{
                          $color='secondary';
                          $severity='Warning';
                      }


                           // Status colors---------------

                           if($fetch_cases['status']=='Submitted'){
                            $statuscolor='info';
                        }elseif($fetch_cases['status']=='Pending'){
                          $statuscolor='warning';
                        }elseif($fetch_cases['status']=='Invalid'){
                          $statuscolor='dark';
                        }elseif($fetch_cases['status']=='Closed'){
                          $statuscolor='primary';
                        }else{
                            $color='secondary';
                            $severity='Warning';
                        }
          ?>
         

            <!-- Card with header and footer -->
            <div class="card">
            
            <div class="card-body">
            <div class="filter">
                  <a class="icon btn-close" href="cases.php" ><i class="bi bi-three-dots"></i></a>
                  
                </div>
              <h5 class="card-title"><?php echo $cate." @ ".$district." <code>[".$nowcase."]</code>" ?>  </h5>

              <!-- Default Tabs -->
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Overview</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Update</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Comment</button>
                </li>
              </ul>
              <div class="tab-content pt-2" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                              <div class="card-body">
                            <h5 class="card-title"><?php echo $fetch_cases['Subject']; ?></h5>
                            Severity: <span class="badge bg-<?php echo $color; ?>"><i class="bi bi-star me-1"></i> <?php echo $severity; ?></span>

                            <!-- List group With Icons -->
                            <div class="row">
                            <ul class="list-group col-lg-6">
                              <li class="list-group-item"><i class="bi bi-star me-1 text-success"></i> Subject: <span class="badge border-secondary border-1 text-secondary"><?php echo $fetch_cases['Subject']; ?></span></li>
                              <li class="list-group-item"><i class="bi bi-collection me-1 text-primary"></i>Reporter:  <span class="badge border-secondary border-1 text-secondary"><?php echo $fetch_cases['client']; ?></span></li>
                              <li class="list-group-item"><i class="bi bi-exclamation-octagon me-1 text-warning"></i> Reported Campany:  <span class="badge border-danger border-1 text-secondary"><?php echo $fetch_cases['who']; ?> </span></li>
                              <li class="list-group-item"><i class="bi bi-check-circle me-1 text-danger"></i> Reported Time: <?php $jointime=$fetch_cases['report_date'];
                        print date("(D) M d, Y - h:m a",$jointime); ?></li>
                            </ul><!-- End List group With Icons -->
                            <ul class="list-group col-lg-6">
                              <li class="list-group-item"> Status: <span class="badge bg-<?php echo $statuscolor; ?>"><i class="bi bi-collection me-1"></i><?php echo $fetch_cases['status']; ?></span></li>
                              <li class="list-group-item"> Progress:</li>
                              <li class="list-group-item" style="height:100px;" rowspan="3"><i class="bi bi-book me-1 text-primary"></i><?php echo $fetch_cases['progress']; ?></li>
                              <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Edit</button>
                            </ul><!-- End List group With Icons -->

                            </div>

                          </div>             
                        
                        </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="card-body">
              <h5 class="card-title">Case Updating</h5>

              <!-- Custom Styled Validation -->
              <form class="row g-3 needs-validation" method="POST" action="cases.php?Q=<?php echo $fetch_cases['caseid']; ?>" novalidate>
                <div class="col-md-12">
                  <label for="validationCustom01" class="form-label">Subject</label>
                  <input type="text" class="form-control" name="casesub" id="validationCustom01" value="<?php echo $fetch_cases['Subject']; ?>"  readonly>
                  <input type="hidden" class="form-control" name="casekey" id="validationCustom01" value="<?php echo $fetch_cases['id']; ?>"  readonly>
                  <div class="valid-feedback">
                    Looks good!
                  </div>
                </div>
                <div class="col-md-8">
                  <label for="validationCustom02" class="form-label">Progress Note</label>
                  
                  <Textarea class="form-control" name="progress" value="<?php echo $fetch_cases['Subject']; ?>" style="height:100px;" require=""><?php echo $fetch_cases['progress']; ?></Textarea>
                  <div class="valid-feedback">
                    Looks good!
                  </div>
                </div>
                <div class="col-md-4">
                  <label for="validationCustomUsername" class="form-label">Update Status</label>
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend"><?php echo $fetch_cases['status']; ?> <></span>
                    <select class="form-control" name="status" required="">
                    <option value="">Select New Status</option>
                      <option value="Closed">Closed</option>
                      <option value="Pending">Pending</option>
                      <option value="Invalid">Invalid</option>
                    </select>
                    <div class="invalid-feedback">
                      Please choose a Status.
                    </div>
                  </div>
                </div>
                
                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                      Agree to terms and conditions
                    </label>
                    <div class="invalid-feedback">
                      You must agree before submitting.
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary" name="Submit-btn" type="submit">Submit form</button>
                </div>
              </form><!-- End Custom Styled Validation -->

            </div>                </div>
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <?php echo $fetch_cases['progress']; ?>                </div>
              </div><!-- End Default Tabs -->

            </div>
          </div>
                              <?php } } ?>
          <!-- Only if case is opened============================================================= -->
            <div class="card-body">
              <h5 class="card-title">All Cases</h5>
              
                <form action=""  id="jegyform" name="jegyform">
                  <!-- Tooltips Examples -->
              
              <div class="col-md-4">
                  <label for="validationCustomUsername" class="form-label">Filter</label>
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">List Only</span>
                    <select class="form-control" name="status" id="filstatus" required="">
                    <option value="all">all Cases</option>
                      <option value="Closed" class="bg-primary text-white">Closed</option>
                      <option value="Pending" class="bg-warning text-white">Pending</option>
                      <option value="Invalid" class="bg-black text-white">Invalid</option>
                    </select>
                    <a type="button" href="cases.php" class="btn btn-secondary input-group-text" id="inputGroupPrepend" data-bs-toggle="tooltip" data-bs-placement="right" title="Cancel filtering">Cancel Filter</a>
                  </div>
                </div>
              
                    </form> 
              <!-- End Tooltips Examples -->
            
              <p>Open a case Review by clicking on a link <code>[case code]</code> in this table Bellow, Also use a search box to sort a Particular cases</p>

              <!-- Table with stripped rows -->
              <table class="table datatable" id="filterresurt">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Case code</th>
                    <th scope="col">Severity</th>
                    <th scope="col">To whom</th>
                    <th scope="col">Location</th>
                    <th scope="col">Status</th>
                    <th scope="col">Start Date</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                  $sel_cases=$con->query("SELECT*from cases ")or die($con->error);
                  while($fetch_cases=$sel_cases->fetch_assoc()){ 
                    $cate=$fetch_cases['category'];
                    $loca=$fetch_cases['location'];
                    
                  $sel_locations=$con->query("SELECT*from locations where id='$loca' ")or die($con->error);
                  $fetch_locations=$sel_locations->fetch_assoc(); 
                             
                   $district=$fetch_locations['district'];


                   $sel_cate=$con->query("SELECT*from categories where id='$cate' ")or die($con->error);
                   $fetch_cate=$sel_cate->fetch_assoc(); 
                              
                    $cate=$fetch_cate['c_title'];

                            if($fetch_cate['severity']=='3'){
                                $color='success';
                                $severity='Minor';
                            }elseif($fetch_cate['severity']=='2'){
                                $color='warning';
                                $severity='Major';
                            }elseif($fetch_cate['severity']=='1'){
                                $color='danger';
                                $severity='Critical';
                            }else{
                                $color='secondary';
                                $severity='Warning';
                            }

                            // Status colors---------------

                            if($fetch_cases['status']=='Submitted'){
                              $statuscolor='info';
                          }elseif($fetch_cases['status']=='Pending'){
                            $statuscolor='warning';
                          }elseif($fetch_cases['status']=='Invalid'){
                            $statuscolor='dark';
                          }elseif($fetch_cases['status']=='Closed'){
                            $statuscolor='primary';
                          }else{
                              $color='secondary';
                              $severity='Warning';
                          }

                  ?>
                  <tr class="table-<?php echo $color; ?>">
                    <th scope="row"><?php echo $fetch_cases['id']; ?></th>
                    <td><?php echo $fetch_cases['Subject']; ?></td>
                    <td><a href="cases.php?Q=<?php echo $fetch_cases['caseid']; ?>"><?php echo $fetch_cases['caseid']; ?></a></td>
                    <td><?php echo $severity; ?></td>
                    <td><?php echo $fetch_cases['who']; ?></td>
                    <td><?php echo $district; ?></td>
                    <td><a href="cases.php?Q=<?php echo $fetch_cases['caseid']; ?>"><span class="badge bg-<?php echo $statuscolor; ?>"><i class="bi bi-collection me-1"></i><?php echo $fetch_cases['status']; ?></span></a></td>
                    <td><?php $jointime=$fetch_cases['report_date'];
                        print date("(D) M d, Y - h:m a",$jointime); ?></td>
                  </tr>
                  <?php }  ?>
                  
                  
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Transparency Rwanda</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://IRASUBIZA Shalon Gladstone.com/license/ -->
      Designed by <a href="https://IRASUBIZA Shalon Gladstone.com/">IRASUBIZA Shalon Gladstone</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>


  <script>


   $(document).ready(function(){
   
    $('#filstatus').on('change', function(event){
          event.preventDefault();
          if($('#filstatus').val() != '')
          {
           var form_data = $(this).serialize();
           $.ajax({
            url:"filtercases.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
             //$('#assign_form')[0].reset();
             $('#filterresurt').html(data);
            }
           })
          }
          else
          {
           alert("Select Filter Please");
          }
         });
 }); 
</script>
   </script>
</body>

</html>
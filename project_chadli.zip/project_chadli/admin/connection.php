
<?php
//define('php_MEMORY_LIMIT','256M');

$con=mysqli_connect('localhost','root','','corruption');

//mysql_connect('localhost','root','');
//mysql_select_db('dov');
if(!$con)
{
	die('Please Check Your Connection'.mysqli_error());
}


?>
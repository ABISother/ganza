
<!-- filtercases.php -->
<?php

include('connection.php'); 

if(isset($_POST['status'])|| isset($_GET['status'])){

    $nstatus=$_POST['status'];
    if($nstatus=='all'){
        echo("<script>location.href='cases.php';</script>");
    }
  ?>

                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Case code</th>
                    <th scope="col">Severity</th>
                    <th scope="col">To whom</th>
                    <th scope="col">Location</th>
                    <th scope="col">Status</th>
                    <th scope="col">Start Date</th>
                    <th scope="col">Comment</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                  $sel_cases=$con->query("SELECT*from cases where status='$nstatus' ")or die($con->error);
                  while($fetch_cases=$sel_cases->fetch_assoc()){ 
                    $cate=$fetch_cases['category'];
                    $loca=$fetch_cases['location'];
                    
                  $sel_locations=$con->query("SELECT*from locations where id='$loca' ")or die($con->error);
                  $fetch_locations=$sel_locations->fetch_assoc(); 
                             
                   $district=$fetch_locations['district'];


                   $sel_cate=$con->query("SELECT*from categories where id='$cate' ")or die($con->error);
                   $fetch_cate=$sel_cate->fetch_assoc(); 
                              
                    $cate=$fetch_cate['c_title'];

                            if($fetch_cate['severity']=='3'){
                                $color='success';
                                $severity='Minor';
                            }elseif($fetch_cate['severity']=='2'){
                                $color='warning';
                                $severity='Major';
                            }elseif($fetch_cate['severity']=='1'){
                                $color='danger';
                                $severity='Critical';
                            }else{
                                $color='secondary';
                                $severity='Warning';
                            }

                            // Status colors---------------

                            if($fetch_cases['status']=='Submitted'){
                              $statuscolor='info';
                          }elseif($fetch_cases['status']=='Pending'){
                            $statuscolor='warning';
                          }elseif($fetch_cases['status']=='Invalid'){
                            $statuscolor='dark';
                          }elseif($fetch_cases['status']=='Closed'){
                            $statuscolor='primary';
                          }else{
                              $color='secondary';
                              $severity='Warning';
                          }

                  ?>
                  <tr class="table-<?php echo $color; ?>">
                    <th scope="row"><?php echo $fetch_cases['id']; ?></th>
                    <td><?php echo $fetch_cases['Subject']; ?></td>
                    <td><a href="cases.php?Q=<?php echo $fetch_cases['caseid']; ?>"><?php echo $fetch_cases['caseid']; ?></a></td>
                    <td><?php echo $severity; ?></td>
                    <td><?php echo $fetch_cases['who']; ?></td>
                    <td><?php echo $district; ?></td>
                    <td><a href="cases.php?Q=<?php echo $fetch_cases['caseid']; ?>"><span class="badge bg-<?php echo $statuscolor; ?>"><i class="bi bi-collection me-1"></i><?php echo $fetch_cases['status']; ?></span></a></td>
                    <td><?php $jointime=$fetch_cases['report_date'];
                        print date("M d, Y",$jointime); ?></td>
                        <td><?php echo $fetch_cases['progress']; ?></td>
                  </tr>
                  <?php }  
                  
}else{
    echo "<option value=''>No cases Selected</option>";
}

?>
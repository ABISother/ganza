<?php
session_start();
   
 include('connection.php'); 

if(isset($_POST['caseid'])){
  $nowcase=$_POST['caseid'];

  if(isset($_SESSION["category"])){
    echo("<script>location.href='reportform.php';</script>");
  }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Report crime</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Header ======= -->
  <?php 
  $active_page='users';
  include'header.php';?>
  <!-- End Header -->

  <main id="main">
  
    <!-- ======= Breadcrumbs ======= -->
   <div class="breadcrumbs">
      <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/page-header.jpg');">
        <div class="container position-relative">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-6 text-center">
              <h2>Case</h2>
              <form action="cases.php" method="Post" class="form-search d-flex align-items-stretch mb-3" data-aos="fade-up" data-aos-delay="200">
            <input type="text" name="searching" class="form-control" placeholder="to Search a case (Put Here Case code)"> 
           
            <button type="submit" class="btn btn-primary">Search</button>
          </form>
            </div>
          </div>
        </div>
      </div>
      <nav>
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Cases</li>
          </ol>
        </div>
      </nav>
    </div>



    <!-- ======= Stats Counter Section ======= -->





    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="service-details" class="service-details">
      <div class="container" data-aos="fade-up">
      <?php         

if(isset($_POST['searching'])){
  $srch=$_POST['searching'];
                $sel_cases=$con->query("SELECT*from cases where caseid='$srch' ")or die($con->error);
                if($count_cases=$sel_cases->num_rows>0){

                            $fetch_cases=$sel_cases->fetch_assoc();
                              $cate=$fetch_cases['category'];
                              $loca=$fetch_cases['location'];
                              
                            $sel_locations=$con->query("SELECT*from locations where id='$loca' ")or die($con->error);
                            $fetch_locations=$sel_locations->fetch_assoc(); 
                                      
                            $district=$fetch_locations['district'];

                            $sel_cate=$con->query("SELECT*from categories where id='$cate' ")or die($con->error);
                            $fetch_cate=$sel_cate->fetch_assoc(); 
                                        
                              $cate=$fetch_cate['c_title'];

                          if($fetch_cate['severity']=='3'){
                              $color='success';
                              $severity='Minor';
                          }elseif($fetch_cate['severity']=='2'){
                              $color='warning';
                              $severity='Major';
                          }elseif($fetch_cate['severity']=='1'){
                              $color='danger';
                              $severity='Critical';
                          }else{
                              $color='secondary';
                              $severity='Warning';
                          }
                      
?>
        <div class="section-header">
          <span><?php echo $fetch_cases['category']; ?></span>
          <h2>Results To the case</h2>

        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-10">
             <div class="row gy-4">

          <div class="col-lg-12" >
            <div class="row">
            <div class="services-list col-lg-6">
            <h4><?php echo $fetch_cate['c_title']; ?></h4>
            <span class="btn btn-<?php echo $color;  ?>">Severity : <?php echo $severity;  ?></span>
              <a  class="active disabled" >Case Code: <?php echo $fetch_cases['caseid']; ?></a>
              
             Status:  <span class="bg-primary"><b><?php echo $fetch_cases['status']; ?></b></span>
              
            
            </div>
            <div class="services-list col-lg-6">
           
           Crime Location :<a class=""> <?php echo $district; ?></a>
              
              <br>
             
              Progress :<a class=""> <?php echo $fetch_cases['progress']; ?></a>
              
            
            </div>
                        </div>

            <?php 
                      }else{ ?>
          <div class="col-lg-12" >
            <div class="services-list">
            <div class="section-header">
          <span>Sorry,Invalid Case</span>
          <h2>Results To the case</h2>

        </div>
              <a  class="active disabled" > There's no such Case Code as <strong><u><?php echo $srch;  ?></u></strong></a>
              
              
            
            </div>

                  <?php    } }
                ?>

            <h4>If you would like to stay anonymous</h4>
            <p>You will be protected by the Transparency Rwanda technology. Please make sure that the information you provide does not contain any reference to you.</p>
          </div>

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php 

  include'footer.php';?>
  
  <!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2022 at 06:56 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `corruption`
--

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `caseid` varchar(60) NOT NULL,
  `category` int(11) NOT NULL,
  `client` varchar(60) NOT NULL DEFAULT 'Unknown',
  `description` varchar(300) NOT NULL,
  `who` varchar(90) NOT NULL,
  `location` int(11) NOT NULL,
  `amount_range` varchar(60) NOT NULL,
  `report_date` varchar(60) NOT NULL,
  `filename` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Submitted',
  `progress` varchar(100) NOT NULL DEFAULT 'This case has been Received, we are looking on this'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `Subject`, `caseid`, `category`, `client`, `description`, `who`, `location`, `amount_range`, `report_date`, `filename`, `status`, `progress`) VALUES
(1, 'Fraud at Gashyekero', 'CASE19278', 2, 'Ganza', 'ibisobanuro byoseeeeeeee', 'RURA', 7, '', '1665598934', '', 'Submitted', 'This case has been Received, we are looking on this'),
(2, 'Fraud at Gashyekero1', 'CASE35019', 2, 'Unknown', 'Fraud at Gashyekero, ibisobanuroooo', 'MTN Rwanda', 1, '10,000-100,000', '1665600021', '', 'Submitted', 'This case has been Received, we are looking on this'),
(3, 'Fraud at Gashyekero2', 'CASE52716', 2, 'Unknown', 'Fraud at Gashyekero, ibisobanuroooo', 'MTN Rwanda', 1, '10,000-100,000', '1665600091', 'NONE', 'Submitted', 'This case has been Received, we are looking on this'),
(4, 'byimenyere', 'CASE30198', 1, 'Unknown', '  x', ' x', 2, '10,000-100,000', '1665670287', 'NONE', 'Submitted', 'This case has been Received, we are looking on this'),
(5, 'Conflict ', 'CASE24719', 3, 'MUNANA', 'Conflict  Of MUNANA', 'St john ltd', 4, '10,000-100,000', '1665671235', 'NONE', 'Submitted', 'This case has been Received, we are looking on this');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `c_title` varchar(90) NOT NULL,
  `explains` varchar(200) NOT NULL,
  `severity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `c_title`, `explains`, `severity`) VALUES
(1, 'Abuse of office', 'A person who uses his office to improperly benefit oneself or another person.\r\n\r\nSome examples:\r\n\r\nbreach of procurement rules to favour somebody\r\nnepotism\r\nfavouritism\r\nabuse of discretion/ power', 2),
(2, 'Fraud', 'The action or instance of deception for financial or personal gain or so as to obtain goods or services illegally\r\n\r\nSome examples:\r\n\r\nFalsification of documents\r\nOver valuing or under valuing of good', 2),
(3, 'Conflict of interest', 'A conflict of interest is a situation in which a public officer has a private interest in a matter that concerns his office and he fails to disclose the private interest to his employer.\r\n\r\nIt is not ', 1),
(4, 'Bribery', 'Giver: To promise, offer, or give something of value to a person in order to obtain services or gain influence; or\r\n\r\nRecipient: To receive or demand, or agree to receive or demand a private benefit s', 2),
(5, 'Tax evasion', 'Failure to pay taxes to the government by individuals, organisations, companies, manufacturers etc.\r\n\r\nSome examples:\r\n\r\nThe taxes include and are not limited to pay as you earn (PAYE)\r\nIncome tax\r\nCl', 2),
(6, 'Breach of Trust', 'Failure to honour a responsibility of trust and confidence bestowed upon a person by virtue of his office.\r\n\r\nSome examples:\r\n\r\nWhere managers of pension funds have irregularly invested member funds i', 3),
(7, 'Land grabbing', 'Fraudulent acquisition and disposal of public land. This includes to illegally acquire, sell, transfer, lease, charge or mortgage or in any way dispose of public land.\r\n\r\nSome examples:\r\n\r\nLand set as', 3),
(8, 'Fraudulent acquisition and disposal of public property', 'To illegally sell, transfer, lease, charge or mortgage or in any way dispose of public property.\r\n\r\nSome examples:\r\n\r\nvehicles\r\ntools\r\nequipment\r\nmoney\r\nbuildings', 0);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `province` varchar(60) NOT NULL,
  `district` varchar(60) NOT NULL,
  `cases` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `province`, `district`, `cases`) VALUES
(1, 'Kigali', 'Kicukiro', 0),
(2, 'Kigali', 'Gasabo', 0),
(3, 'Kigali', 'Nyarugenge', 0),
(4, 'Southern Province', 'Muhanga', 0),
(5, 'Southern Province', 'Nyanza', 0),
(6, 'Western Province', 'Rubavu', 0),
(7, 'western province', 'Rusizi', 0),
(8, 'Western Province', 'Ngororero', 0),
(9, 'western province', 'Nyamasheke', 0),
(10, 'Western Province', 'Rutsiro', 0),
(11, 'Eastern Province', 'Bugesera', 0),
(12, 'Eastern Province', 'Gatsibo', 0),
(13, 'Eastern Province', 'Kayonza', 0),
(14, 'Eastern Province', 'Kirehe', 0),
(15, 'Eastern Province', 'Ngoma', 0),
(16, 'Eastern Province', 'Nyagatare', 0),
(17, 'Eastern Province', 'Rwamagana', 0),
(18, 'Southern Province', 'Gisagara', 0),
(19, 'Southern Province', ' Huye', 0),
(20, 'Southern Province', 'Kamonyi', 0),
(21, 'Southern Province', 'Nyamagabe', 0),
(22, 'Southern Province', 'Nyaruguru', 0),
(23, 'Southern Province', 'Ruhango', 0),
(24, 'Northern Province', 'Burera', 0),
(25, 'Northern Province', 'Gakenke', 0),
(26, 'Northern Province', 'Gicumbi', 0),
(27, 'Northern Province', 'Musanze', 0),
(28, 'Northern Province', 'Rulindo', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `possition` varchar(60) NOT NULL DEFAULT 'Investigator',
  `image` varchar(60) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Offline',
  `last_seen` varchar(60) NOT NULL DEFAULT '1649272407',
  `password` varchar(60) NOT NULL,
  `account_type` varchar(60) NOT NULL DEFAULT 'User'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `email`, `possition`, `image`, `phone`, `status`, `last_seen`, `password`, `account_type`) VALUES
(1, 'Ganza', 'ganza@gmail.com', 'Investigator', 'profile-img.jpg', '0780669420', 'Online', '1665647876', '202cb962ac59075b964b07152d234b70', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
?>
<?php
if(!isset($_SESSION["category"])){
  echo '<script>alert("Choose a Category First");</script>';
echo("<script>location.href='report.php?Choose';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){


}
else{

    include('connection.php'); 
$category_key=$_SESSION["category"];
$sel_category=$con->query("SELECT*from categories WHERE id='$category_key' ")or die($con->error);
$fetch_category=$sel_category->fetch_assoc();

 $nowcat=$fetch_category['c_title'];

$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_category['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}?><?php
//process.php

require_once('connection.php');

if(isset($_POST['subject']))
{
  $subject=$_POST['subject'];
  $subject=str_replace("'", "\'", $subject);

  $username=$_POST['username'];
  $username=str_replace("'", "\'", $username);

  $discription=$_POST['discription'];
  $discription=str_replace("'", "\'", $discription);

  $private=$_POST['private'];
  $m_name=$_POST['who'];
  $location=$_POST['district'];  
  $amount_range=$_POST['amount_range'];  
  if(isset($_POST['myfile']))
{
  $data=$_POST['myfile'];
  // $proof=str_replace("'", "\'",   $proof);
 
  $img_array_1 = explode(";", $data);
  $img_array_2 = explode(",", $img_array_1[1]);
  $basedecode = base64_decode($img_array_2[1]);
  $filename = time().'_proof.pdf';
  file_put_contents("assets/proofs/$filename", $basedecode);
  //file_put_contents($filename, $basedecode);
}else{
  $filename='NONE';
}

    $now=time();
   
    //===========generate the sku=============
function checkkeys($con,$randstr){
	$sql ="SELECT * FROM cases";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['caseid']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 5;
$str="1234567890";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$sku=generatekey($con);
$caseid='CASE'.$sku;
//------------======------End of sku Generations----========----


    $sel_subject=$con->query("SELECT*from cases where Subject='$subject'  ")or die($con->error);
    if($count_subject=$sel_subject->num_rows>0){
      $fetch_subject=$sel_subject->fetch_assoc();
      $m_name=$fetch_subject['caseid'];
      $alert="<strong>Sorry, You have Repported This Subject Already! <a href='reportform.php>Check case $m_name </a> </strong>"; 
      echo("<script>location.href='reportform.php?alert= $alert';</script>");  
    }

 
    if(!isset($alert)){
      $savequery=$con->query("INSERT INTO cases(Subject,caseid,category,client,description,who,location,amount_range,report_date,filename) VALUES ('$subject','$caseid','$category_key','$username','$discription','$m_name','$location','$amount_range','$now','$filename')")or die($con->error);
      if ($savequery) {
          $approvo="Report is Submited Thanks For your Support,<br> Ubutumwa Bwawe bwakiriwe neza, Murakoze gutanga umusanzu mukurwanya Ruswa Mugi!<br> ";
         
          //echo '<label style="color:Blue;">Success! <br/>Your claim on '.$m_name.' Has been Submited</label>';
          //$saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','New Name has been Added','info','New name: $fName. has been added to the system','$now')")or die($con->error);
      // if(isset($_SESSION["new_member"])){
          //   echo("<script>location.href='new_2.php';</script>");
          //  }
          // sleep(7);
          echo("<script>location.href='success.php?info=Success<br/>Your Repport has case code <b> $caseid </b> Has been Submited';</script>");
         
             } 
    }else{
      echo("<script>location.href='reportform.php?alert=Sorry<br/> $alert';</script>");
      echo '<label style="color:red;">'.$alert.' </label>';
     }


  }

?>
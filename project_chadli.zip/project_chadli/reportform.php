<?php
session_start();
?>
<?php
if(!isset($_SESSION["category"])){
  echo '<script>alert("Choose a Category First");</script>';
echo("<script>location.href='report.php?Choose';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){


}
else{

    include('connection.php'); 
$category_key=$_SESSION["category"];
$sel_category=$con->query("SELECT*from categories WHERE id='$category_key' ")or die($con->error);
$fetch_category=$sel_category->fetch_assoc();

 $nowcat=$fetch_category['c_title'];

$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_category['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Form Page - Transparency Rwanda</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

   <!-- Ajax reasons-->
   <script src="assets/js/jquery.min.js"></script>


  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Logis - v1.1.0
  * Template URL: https://bootstrapmade.com/logis-bootstrap-logistics-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">

  </header><!-- End Header -->
  <!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
     <div class="breadcrumbs">
      <!--<div class="page-header d-flex align-items-center" style="background-image: url('assets/img/page-header.jpg');">
        <div class="container position-relative">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-6 text-center">
              <h2>INCIDENT REPORTING</h2>
            </div>
          </div>
        </div>
      </div> -->
      <nav>
        <div class="container">
        <div class="col-lg-6 text-center">
              <h2>INCIDENT REPORTING</h2>
            </div>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Report</li>
            
          </ol>
        </div>
      </nav>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Service Details Section ======= -->
    <section id="service-details" class="service-details">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">

          <div class="col-lg-4" >
            <div class="services-list">
              <a  class="active disabled" >Report to be sent to: Transparency Rwanda</a>
             
              <a class="active disabled">Category: <?php echo  $nowcat; ?></a>
              
            
            </div>

            <h4>If you would like to stay anonymous</h4>
            <p>You will be protected by the Transparency Rwanda technology. Please make sure that the information you provide does not contain any reference to you.</p>
          </div>

          <div class="col-lg-8 services-list">
            <!-- <img src="assets/img/service-details.jpg" alt="" class="img-fluid services-img"> -->
            <font color="red">*</font> Required field
            <form name="report_form" action="process.php" method="POST" >
            <div class="divider"></div>
            <br>
            <div class="col-lg-8">
            <label id="forstatename"><font color="red">*</font> Subject </label>
                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required="">
            </div>
            <br>
            <div class="form-group">
                <label id="forstatename"><font color="red">*</font> Do you want to state your name? </label>
                
                <div class="col-lg-3">
                <input type="radio" id="hidename" name="statename" value="No" placeholder="Subject" data-bs-toggle="collapse" data-bs-target="#faq-content-1" checked> No
                </div>
                <div class="col-lg-3">
                <input type="radio" id="unhidename" data-bs-toggle="collapse" data-bs-target="#faq-content-1" name="statename" value="Yes" placeholder="Subject"> Yes
                  </div>
               <!-- # Faq item-->
                <div class="accordion-item">
                
                <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                  <div class="col-lg-8 hidden uname" id="uname" >
                  <p>If yes, be aware that you voluntarily give up your anonymity.</p>
                <label id="forstatename">Please enter your contact information: </label>
                <br>
                <strong>Name: </strong>
                <input type="text" id="cname" name="username" class="form-control col-md-4" value="Unknown" placeholder="Name"> 
                </div>
                  </div>
                </div>
              </div><!-- # Faq item-->

                
            </div>
            <br>
            <div class="row">
            <div class="col-lg-8">
            <label id="fordescribe"><font color="red">*</font> Please describe the incident in as much detail as possible:</label>
                <textarea class="form-control" id="discription" name="discription"  maxlength='200' placeholder="Descriptions" required=""></textarea>
            </div>
            <!-- <div class="col-lg-5">If you would like to stay anonymous, you will be protected by the Transparency technology. Please make sure that the information you provide does not contain any reference to you.</div> -->
            </div>
            <br>
           
            <h4>Please answer the following questions in order to optimize processing your report even if you have already provided the answers in the text field above:</h4>
            <div class="col-lg-8">
            <label id="forstatename"><font color="red">*</font> Which public organisation/ person are you complaining about?</label>
                <input type="text" class="form-control" id="who" name="who" placeholder="public organisation/ person " required="">
            </div>
            <br>
            <div class="form-group">
                <label id="forstatename"> Is there a private organisation involved? </label>
                <div class="col-lg-3">
                <input type="radio" id="subject" name="private" value="Yes" placeholder="Subject"> Yes
            </div>
                <div class="col-lg-3">
                <input type="radio" id="subject" name="private" value="No" placeholder="Subject"> No
                </div>
            </div>
            <br>
            <div class="col-lg-8">
            <label id="forstatename"><font color="red">*</font> In which province did the incident take place?</label>
                
                <select class="form-control" id="province" name="province" >
                  <option value="">-Select Province- </option>
                  <?php
                  $sel_locations=$con->query("SELECT DISTINCT province from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                             
                  <option value="<?php echo $fetch_locations['province'] ?>" >
                  <?php echo $fetch_locations['province'] ?> </option>
                  <?php }  ?>
                  
              </select>
              <script>
   
  
        $(document).ready(function(){
        
         $('#province').on('change', function(event){
          event.preventDefault();
          if($('#province').val() != '')
          {
           var form_data = $(this).serialize();
           $.ajax({
            url:"seldistrict.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
             //$('#assign_form')[0].reset();
             $('#seldistrict').html(data);
            }
           })
          }
          else
          {
           alert("Select Province Please");
          }
         });
        });
        </script>

            </div>
            <br>
            <div class="col-lg-8" id="disctrict">
            <label id="forstatename"><font color="red">*</font> In which district did the incident take place?</label>
                
                <select class="form-control" id="seldistrict" name="district">
                  <option value="">-Select Province First!- </option>

                   <?php
                  $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                             
                  <option value="<?php echo $fetch_locations['id'] ?>" >
                  <?php echo $fetch_locations['district'] ?> </option>
                  <?php }  ?>
                  
              </select>
            </div>
            <br>
            <br>
            <div class="col-lg-8">
            <label id="forstatename"><font color="red">*</font> What was the approximate amount of monetary damage in Rwandan Francs?</label>
                
                <select class="form-control" id="who" name="amount_range" required="">
                  <option value="">-Select amount- </option>
                  <option value="10,000">Bellow 10,000 </option>
                  <option value="10,000-100,000">10,000-100,000 </option>
                  <option value="100,000-1,000,000">100,000-1,000,000</option>
                  <option value="Over 1 Million">Over 1 Million </option>
                  <option value="Over 5 Million">Over 5 Million</option>
                  <option value="Unknown">Unknown </option>
              </select>
            </div>
            <br>
            <div class="form-group">
                <label id="forstatename"> <font color="red">*</font>Do you have any documents to support your report? </label>
                <div class="col-lg-3">
                <input type="radio" id="doc" name="doc" value="1" placeholder="Subject"> Yes
            </div>
                <div class="col-lg-3">
                <input type="radio" id="doc" name="doc" value="0" placeholder="Subject"> No
                </div>
            </div>
            <br>
            <div class="col-lg-12" >
            <div class="services-list">
              
            

            <p><strong>Attachment:</strong> You can attach a file of up to 5 MB.</p>
            <a  class="active disabled" ><p><strong>Note on sending attachments:</strong> Files may contain hidden personal information that could jeopardise your anonymity. If you wish to remain anonymous, please remove all such information before sending a file. If you are unable to remove such information, copy the text from your file into the report text or send a printed copy of the document anonymously using the reference number that is provided at the end of the reporting process to the examiner's address (see footnote).</p>
          </a>

          <div class="col-lg-8">
                <input type="checkbox" id="doc" name="doc" value="0" placeholder="Subject"> Note has been acknowledged.
                </div>

                <div class="col-lg-8">
            
                <input type="file" class="form-control" id="myfile" name="file" placeholder="Choose your FILE ">
            </div>
              <BR>
            <p>
            If you want to send more than one file, create your secured postbox at the end of this process. There you can send more attachments as an addition.
            </p>
          </div>

          If you have any documents to support your report, take note of the number which will be assigned to your report after you click send, write it on the document and send it to Transparency International Rwanda.
          <BR><BR>
          <div class="col-lg-8 pull-right">
          <a class="get-a-quote" href="">Back</a>
          <button type="reset" class="btn btn-info">Clear</button> <button type="Submit" name="reportbtn" class="btn btn-primary">Send</button>
            </div>

            </form>
          </div>

            
            
          </div>

        </div>

      </div>
    </section><!-- End Service Details Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php 

include'footer.php';?>

<!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script> 
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
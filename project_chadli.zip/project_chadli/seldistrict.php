
<!-- seldistrict -->
<?php
 include('connection.php'); 
if(isset($_POST['province'])){

    $nprovince=$_POST['province'];
    echo $nprovince;
  
    $sel_locations=$con->query("SELECT*from locations where province='$nprovince' ")or die($con->error);
    if($count_locations=$sel_locations->num_rows>0){
    while($fetch_locations=$sel_locations->fetch_assoc()){ 
        $nid=$fetch_locations['id'];
        $ndi=$fetch_locations['district'];
               
        echo "<option value=$nid >$ndi</option>";
        //echo "<option value=''>location 1</option>";
 
        }
    }else{
        echo "<option value=''>No such province Select Province Again</option>";
    }
}else{
    echo "<option value=''>Select province above</option>";
}

?>